// const spanElement = document.createElement('span');
// spanElement.innerHTML='hello guys';

// const pElement = document.createElement('p');
// pElement.appendChild(spanElement);

// const divRoot = document.getElementById('root');
// console.log(divRoot)
// divRoot.appendChild(pElement);

 /* const spanReactElement = React.createElement('span', { id: 'sp1', style: 'font-family:Arial' }, 'Hello guys');
    const buttonReactElement = React.createElement('button', { id: 'changeBtn', value: 'Click', onClick=() => alert('Hi') });
    const divReactElement = React.createElement('div', { id: 'd2' }, spanReactElement, buttonReactElement)
    return divReactElement; */

    /* const welcomeReactElement = Welcome();
    const inputReactElement = React.createElement('input', { type: 'text' });
    const divReactElement = React.createElement('div', { id: 'd1' },
        welcomeReactElement, inputReactElement);
        
    return divReactElement; */

/*     const rootDiv = document.getElementById("root");
const completeDesign = Container();
ReactDOM.render(completeDesign, rootDiv); */