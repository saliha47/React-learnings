import React from "react";

export function Welcome() {
  /* const styles: {
    ("font-family:Arial");

    style={styles}
  } */
  function onClickChange() {
    console.log(document.getElementById(root));
    // return (document.getElementById(sp1).nodeValue=" Hi Guys it is the click");
  }
  return (
    <div id="d2">
      <span id="sp1" >
        "Hello Guys"
      </span>
      <button id="changeBtn" onClick={onClickChange}>
        Click
      </button>
    </div>
  );
}
