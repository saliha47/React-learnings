import React from "react";
import { Welcome } from "./Welcome";

function Container() {
  return (
    <div id="d1">
      <Welcome />
      <input type="text"></input>
    </div>
  );
}

export default Container;
//module.exports = Welcome;
