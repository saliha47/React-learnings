import React from "react";

import "./App.css";
import CounterRenderProps from "../components/CounterRenderProps";
import ClickCounter from "../components/ClickCounter";

const testRenderProps = (CountValue, IncreaseFunc, DecreaseFunc) => {
  return <ClickCounter CountValue={CountValue} IncreaseFunc={IncreaseFunc} DecreaseFunc={DecreaseFunc} />;
};

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <CounterRenderProps render={testRenderProps} />
      </header>
    </div>
  );
}

export default App;
