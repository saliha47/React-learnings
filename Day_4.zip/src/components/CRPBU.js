import React from 'react'

const funcFromCounterRenderProp = () => {
return 26;
}

function CounterRenderProps(props) {
    return (
        <div>
            {props.render('hello Saliha',funcFromCounterRenderProp) }
        </div>
    )
}
/* 
export default CounterRenderProps

import React, { Component } from "react";

class CounterRenderProps extends Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 0,
    };
  }
  increaseCounter = () => {
    this.setState((ps) => {
      return {
        count: ps.count + 1,
      };
    });
  };
  decreaseCounter = () => {
    this.setState((ps) => {
      return {
        count: ps.count - 1,
      };
    });
  };
  funcFromCounterRenderProp = () => {
    return 26;
  };
  render() {
    console.log("in counterRendered Props");
    return (
      <div>
        {this.props.render(
          this.count,
          this.increaseCounter(),
          this.decreaseCounter()
        )}
      </div>
    );
  }
}

export default CounterRenderProps;

// const funcFromCounterRenderProp = () => {
// return 26;
// }

// function CounterRenderProps(props) {
//     return (
//         <div>
//             {props.render('hello Saliha',funcFromCounterRenderProp) }
//         </div>
//     )
// }
 */
