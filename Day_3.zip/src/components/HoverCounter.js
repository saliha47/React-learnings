import React from "react";

/**
 * [name,age]
 * {
 *   name:'',
 *   age:20,
 * }
 */
// const changeHandler = (value, product, property, callback) => {
//     console.log('within child')
//     product[property] = value;
//     callback(product);
// }
//w.r.t props a component should act like a PURE Function 
function HoverComponent(props) {
  console.log("pe rendered");
  const { Hover, HoverCountvalue } = props;
  return (
    <div>
      <div onMouseOver={Hover} >
        <span>{HoverCountvalue}</span> 
      </div>
      
    </div>
  );
}

export default HoverComponent;

/**
 * x:{
 * product:{},
 * data:'joydip'
 * }
 *
 * {
 *  type:div,
 *  key:null,
 *  ref: null,
 *  props:{
 *   product:{},
 *   data:'joydip',
 *   children:[hello guys]
 *  }
 * }
 */
