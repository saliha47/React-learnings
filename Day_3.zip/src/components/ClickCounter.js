import React from "react";

/**
 * [name,age]
 * {
 *   name:'',
 *   age:20,
 * }
 */
// const changeHandler = (value, product, property, callback) => {
//     console.log('within child')
//     product[property] = value;
//     callback(product);
// }
//w.r.t props a component should act like a PURE Function 
function ClickComponent(props) {
  console.log("pe rendered");
  const { Click, ClickCountValue } = props;
  return (
    <div>
      <div >
      <button onClick={Click}>Click</button>

        <span>{ClickCountValue}</span> 
      </div>
      
    </div>
  );
}

export default ClickComponent;

/**
 * x:{
 * product:{},
 * data:'joydip'
 * }
 *
 * {
 *  type:div,
 *  key:null,
 *  ref: null,
 *  props:{
 *   product:{},
 *   data:'joydip',
 *   children:[hello guys]
 *  }
 * }
 */
