const {Employee} = require('./employee');
class HR extends Employee {
    constructor (name, id, basicPay=20000, daPay=15000, hraPay=0, gratuityPay=15000){
        super (name, id, basicPay, daPay, hraPay)
        this.gratuityPay = gratuityPay;
    }
    calculateSalary() {
        return super.calculateSalary() + this.gratuityPay;
    }
}

module.exports = { HR };