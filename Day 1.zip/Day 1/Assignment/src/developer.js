const {Employee} = require ('./employee');

class Developer extends Employee {
    constructor (name, id, basicPay=50000, daPay=9999, hraPay=9898, incentive=870){
        super (name, id, basicPay, daPay, hraPay)
        this.incentive = incentive;
    }
    calculateSalary ()  {
        return super.calculateSalary() + this.incentive;
    }
}
module.exports = { Developer };