const { Developer } = require ('./developer');
const { HR } = require('./hr');
const Employees = [ new Developer('Dev1' , 'ABCXYZ', 2020, 1010,1000), 
                    new HR ('HR1' , 'ABCXYZ', 2020, 1000), 
                    new HR ('HR2' , 'ABCXYZ', 2020), 
                    new Developer('Dev2' , 'ABCXYZ', 2020 ,1000)]

Employees.forEach( EmployeeObject => {
    console.log(`Employee Name : ${ EmployeeObject.employeeName} and Salary is ${EmployeeObject.calculateSalary()}`);    
});