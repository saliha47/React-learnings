import React from 'react'

const personData = {
    name: 'joydip',
    age: 20
};
function Person() {
    return (
        <div>
            <span>{personData.name}</span>
            <br />
            <span>{personData.age}</span>
        </div>
    );
}
export default Person;